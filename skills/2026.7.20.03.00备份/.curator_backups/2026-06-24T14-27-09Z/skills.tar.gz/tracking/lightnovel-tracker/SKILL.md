---
name: lightnovel-tracker
description: >
  Scrape 轻之国度 (lightnovel.cn) for latest Japanese/Korean light novel
  translation updates. Covers SSR NUXT-state extraction, API endpoint
  discovery from webpack chunks, and known site architecture constraints.
  Also documents the general technique for scraping Nuxt.js SPAs via
  embedded `window.__NUXT__` state.
---

# 轻之国度 (LightNovel.cn) Tracker

Scrape https://www.lightnovel.cn for the latest Japanese/Korean light novel
translation posts. The site is a Nuxt.js SPA with auth-gated APIs, so the primary
data source is the homepage SSR `__NUXT__` state.

## Triggers

- Cron job or user asks to check lightnovel.cn for new translations
- Any task involving scraping a Nuxt.js SPA site via SSR state

## Step 1 — Fetch homepage and extract NUXT state

**Primary approach**: Try `lightnovel.fun` directly with `--noproxy '*'`. This domain
resolves to `66.94.115.188` and has consistently worked when `.cn` fails.

```bash
curl -s -L --connect-timeout 15 --max-time 45 \
  --noproxy '*' \
  -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" \
  "https://lightnovel.fun/" -o /tmp/ln_home.html
```

**Fallback via `.cn` domain** (may redirect to `.fun`):

```bash
curl -s -L --max-time 30 \
  -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" \
  "https://www.lightnovel.cn/" -o /tmp/ln_home.html
```

**Behind a proxy** (e.g. mihomo on `127.0.0.1:7897`): TLS handshake through the
proxy can take 15–30s. Use extended timeout. If the proxy returns 502, skip it
and use `--noproxy '*'` with the `.fun` domain directly:

```bash
curl -s -L --connect-timeout 15 --max-time 45 \
  -x http://127.0.0.1:7897 \
  -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36" \
  "https://www.lightnovel.cn/" -o /tmp/ln_home.html
```

The HTML contains a `<script>` with the SSR state:

```js
window.__NUXT__=(function(a,b,c,...){return {layout:"default",data:[{...}]}}(0,1,...));
```

The function parameters are positional: `a=0, b=1, c="url", d="", e=2, f=13, ...`
Values in the data object are single-letter references to these params.

## Step 2 — Parse NUXT data to extract light novel entries

Use regex to extract the data object:

```python
nuxt_match = re.search(
    r'window\.__NUXT__=\(function\([^)]+\)\{return (\{.*?)(?:;)?\}\((.*?)\)\);</script>',
    html, re.DOTALL
)
data_str = nuxt_match.group(1)   # The JS object literal
params_str = nuxt_match.group(2)  # The comma-separated argument values
```

### Map parameters

```python
func_params = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,_,$,aa,ab,ac,ad,ae,af,ag".split(',')
raw_params = params_str.split(',')
param_map = dict(zip(func_params, raw_params))
# Resolve: strip quotes, unescape \u002F → /, \u003D → =, etc.
```

### Find the light novel section

The light novel section has `more_params:"3,106,1"` (fid=3, typeid=106).
Find it by locating this string in the data, then extract the enclosing `{...}` block.

**Critical**: There are **two** `more_params` sections in the data — one for category 1 (news, at offset ~2377) and one for category 3/106 (LN, at offset ~7259). Always scope to the second one. Search for the literal string `more_params:"3,106,1"`.

**Finding section boundaries** — the LN section sits inside `data:[...]` as one of several category objects delimited by `},{gid:`:

```python
ln_idx = data_obj.find('more_params:"3,106,1"')
# Go backwards to find opening {
section_start = ln_idx
depth = 0
while section_start > 0:
    section_start -= 1
    c = data_obj[section_start]
    if c == '}': depth += 1
    elif c == '{':
        if depth == 0: break
        depth -= 1

# Find section end: look for the next category boundary
next_section = data_obj.find('},{gid:', ln_idx)
if next_section < 0:
    next_section = data_obj.find('},{', ln_idx)
section_end = next_section + 1 if next_section > 0 else len(data_obj)

ln_section = data_obj[section_start:section_end]
```

**All `ranks:[` and `items:[` searches must be scoped to `ln_section`**, not the full data object. The full data has arrays for other categories (news, etc.) that will pollute results.

### Extract entries

- **ranks** array: `{rank:N, aid:N, title:"...", cover:"...", comments:N, hits:N, time:"YYYY-MM-DD HH:MM:SS", ...}`
  - Has **full metadata**: author in brackets `[作者]`, explicit timestamps, hit counts
  - Stale: shows featured/ranked content, lags 7+ days behind latest uploads in observed sessions
  - **Simpler parsing** — rank entries have flat structure (no nested `{}` outside quoted strings). Instead of bracket-depth tracking, find all `{rank:` positions with regex and split on them:
    ```python
    ranks_start = ln_section.find('ranks:[')
    ranks_part = ln_section[ranks_start+7:]
    rank_positions = [m.start() for m in re.finditer(r'\{rank:', ranks_part)]
    rank_positions.append(len(ranks_part))
    rank_chunks = []
    for i in range(len(rank_positions)-1):
        chunk = ranks_part[rank_positions[i]:rank_positions[i+1]].rstrip(', \t\n\r')
        rank_chunks.append(chunk)
    ```
    Then extract fields with regex: `aid:(\w+)`, `title:"((?:[^"\\]|\\.)*)"`, `time:"([^"]*)"`.
- **items** array: `{id:N, type:N, title:"...", action_params:N, pic_url:"...", ...}`
  - Has **newer content** (higher aid numbers) but **no author, no explicit timestamp**, no description
  - Each `pic_url` contains `t=<unix_epoch>` — the CDN cover-image upload timestamp, a reliable proxy for publish date
  - items without `pic_url` timestamps: fall back to aid-number heuristic (higher = newer)
  - **Same split-on-`{id:` technique** works for items too: find all `{id:` positions with regex, split on boundaries.

Entry URLs follow the pattern: `https://www.lightnovel.cn/cn/article/{aid}`

## Step 3 — Extract timestamps and filter

### For ranks entries (explicit `time` field)
- Parse `time` fields, filter for entries within the desired window (e.g. last 3 days)
- `time` format: `"YYYY-MM-DD HH:MM:SS"` — use `datetime.strptime()`

### For items entries (no explicit time field)
Items lack a `time` field but their `pic_url` carries a CDN timestamp.

**Extract the items array** — use bracket-depth tracking starting from `items:[`
(the offset includes the opening `[`, so `depth` starts at 0 before it):

```python
items_start = ln_raw.find('items:[')
depth = 0
items_raw = ""
for i in range(items_start, len(ln_raw)):
    c = ln_raw[i]
    if c == '[': depth += 1
    elif c == ']':
        depth -= 1
        if depth == 0:
            items_raw = ln_raw[items_start+7:i]  # skip 'items:['
            break
```

Then split objects by matching `{`/`}` depth:

```python
def split_objects(raw):
    parts = []
    depth = 0
    last = 0
    for i, c in enumerate(raw):
        if c == '{':
            if depth == 0: last = i
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                parts.append(raw[last:i+1])
    return parts
```

**Extract CDN timestamps** — always use timezone-aware datetimes (CST=UTC+8)
to match the site's timezone. Mixing naive and aware datetimes causes
`TypeError` during comparison with ranks' explicit times:

```python
from datetime import datetime, timedelta, timezone
CST = timezone(timedelta(hours=8))

t_match = re.search(r'[?&]t=(\d+)', pic_url)
if t_match:
    ts = int(t_match.group(1))
    if 1000000000 < ts < 2000000000:  # Valid Unix epoch (2001–2033)
        cdn_time = datetime.fromtimestamp(ts, tz=CST)
```

**Make ranks datetimes timezone-aware too**:
```python
dt = datetime.strptime(tm.group(1), '%Y-%m-%d %H:%M:%S').replace(tzinfo=CST)
cutoff = datetime(2026, 6, 1, tzinfo=CST)
```

The `t=` value is a Unix epoch second — the cover image upload time, which closely approximates the article publish date. Treat it as the entry date for filtering.

If `pic_url` has no valid timestamp (e.g. `t=8000000000` is a static placeholder), fall back to the aid-number heuristic: recent average is ~8–14 aids/day, so estimate `date ≈ last_known_date + (aid - last_known_aid) / 10 days`.

### Filtering
- Filter out 国产网文 (Chinese web novels): look for Japanese author names in brackets like `[西条阳]`, `[白井ムク]`, or Korean `[최지인]`
- Items array has no author info — cross-reference with known series or check title patterns (isekai themes, JP naming conventions) to distinguish JP/KR from CN
- **Fallback author lookup**: when `extract_author()` returns `None` for an items entry, consult `references/known-series-authors.md` for hardcoded series→author mappings. Only use this as a secondary source — bracket-extracted authors from ranks are always authoritative.
- Disambiguation heuristics (see `references/title-parsing.md` for regex patterns):
  - Kana in author bracket → 日轻; Hangul → 韩轻
  - Pure kanji in brackets within category 3/106 → almost always 日轻
  - No brackets at all (items array) → treat as 日轻 by default in this category

### Extract author and volume
Use the patterns in `references/title-parsing.md` to:
- Strip `[作者]` from titles for author attribution
- Detect volume numbers, chapter markers, and completion status from title text

**Author display cleanup**: After extracting the author from `[brackets]`, strip the bracket from the display title to avoid duplication like `[七星蛍] [七星蛍]班上最優秀的她...`:
```python
def clean_title(title, author):
    t = re.sub(r'\[.*?\]\s*', '', title).strip()
    return t
```

## Known API endpoints (auth required)

Discovered from webpack chunk `b4bd28379f024a47d9fd.js`. All return `{"code":4,"message":404}` without login session:

| Endpoint | Purpose |
|---|---|
| `/api/recom/get-pc-home` | Homepage data (used for SSR) |
| `/api/recom/get-ranks` | Rankings |
| `/api/category/get-article-by-cate` | Articles by category (the one we need) |
| `/api/category/get-article-cates` | Article categories |
| `/api/category/get-categories` | Categories list |

## Site architecture

- **Primary domain**: `lightnovel.fun` (resolves to `66.94.115.188`, works directly with `--noproxy '*'`)
- **Redirect domain**: `lightnovel.cn` → redirects to `lightnovel.fun`; but SSL handshake often times out (Cloudflare IPs `104.21.85.216` / `172.67.211.107`)
- **Blocked**: `lightnovel.us` is behind Cloudflare JS challenge — unusable with curl
- **Routes**: `/cn/article/{aid}`, `/cn/forum/{gid}`, `/cn/themereply/{id}`
- **SSR**: Only the homepage (`/`) is SSR-rendered. All other routes return the SPA shell with empty NUXT data and HTTP 404 status
- **gid mapping**: `13` = 轻小说 (light novel), `12` = 资讯 (news), etc.
- **Article types**: `cover_type: 0` = text, `cover_type: 1` = image/cover

## Pitfalls

- **Auth wall**: APIs require a login session. The homepage SSR is the only public data source
- **NUXT extraction regex fragile**: The Step 2 regex `r'window\.__NUXT__=\(function\([^)]+\)\{return (\{.*?\})\}\((.*?)\)\);'` often fails because the data object is huge (~18KB) and the non-greedy `.*?` stops too early or the greedy version overshoots. Instead, find `window.__NUXT__=` manually, locate `</script>` as the terminator, then use `rfind('}(')` to split the data object from the args:
  ```python
  idx = html.find('window.__NUXT__=')
  end = html.find('</script>', idx)
  nuxt = html[idx:end]
  last_close = nuxt.rfind('}(')  # boundary between DATA }(ARGS)
  data_obj = nuxt[params_match.end():last_close]
  args_str = nuxt[last_close+2:nuxt.find('));', last_close)]
  ```
- **Two `more_params` sections**: The data has two category sections — category 1 (news) and category 3/106 (LN). Always search for `more_params:"3,106,1"` specifically, and scope ALL `ranks:[`/`items:[` extraction to within that section's `{...}` block only. Searching globally will mix news entries with LN entries.
- **`.cn` domain unreachable**: `lightnovel.cn` (Cloudflare IPs `104.21.85.216` / `172.67.211.107`) frequently times out on SSL handshake. IPv6 is unreachable; IPv4 connects but TLS fails. Direct connection gets past Cloudflare but SSL still times out. **Use `lightnovel.fun` directly with `--noproxy '*'`** — it resolves to `66.94.115.188` and has consistently worked across sessions
- **Stale ranks vs fresh items**: The `ranks` array is curated/featured content — can lag 7+ days behind. The `items` array carries newer entries but with less metadata. Check BOTH arrays and merge results. The items array often contains the only entries within a 3-day recency window
- **Items array is cumulative across sessions**: The SSR `items` array persists the same entries across multiple days (entries from 05-27 were still present on 06-01). Do NOT assume all items are recent — ALWAYS validate each item's CDN timestamp. Items migrate to the `ranks` array over time (observed: aid=1144581 in items on 05-29, moved to ranks by 06-01), but items are never removed from the items array within the observed ~10-entry window
- **Items array extraction**: The `items:[...]` array is nested inside the LN section object. Simple regex like `re.findall(r'\{[^}]+\}', items_raw)` fails when titles contain `{` or when URLs have query params. Use bracket-depth tracking: start from `items:[`, count `[`/`]` depth to find the closing `]`, then use `split_objects()` with `{`/`}` depth matching — OR use the simpler split-on-key pattern: find all `{id:` positions in `items_part`, split on those boundaries
- **Items lack author metadata**: Items entries have only `id`, `type`, `title`, `action_params` (aid), `pic_url`, `group_id`, `comments`, `hits`. No author field, no description. Supplement author info from known series or cross-reference with ranks entries that share the same aid
- **No timestamps on items — use CDN timestamps**: The `items` array lacks explicit `time` fields. Extract the `t=<unix_epoch>` from `pic_url` as the primary dating method. Validate: timestamps in range 1e9–2e9 are valid Unix epochs; `t=8000000000` and similar static values are placeholders — discard them and fall back to aid-number heuristic
- **Timezone handling**: CDN timestamps are Unix epochs (always UTC). Use `datetime.fromtimestamp(ts, tz=CST)` for timezone-aware datetimes. Ranks' explicit `time` fields must also be made aware with `.replace(tzinfo=CST)`. Mixing naive and aware datetimes in comparisons raises `TypeError`
- **JS object literal, not JSON**: The NUXT state is a JS expression, not valid JSON. Use regex extraction, not `json.loads()`
- **Cloudflare on .us domain**: `lightnovel.us` requires JS challenge, curl won't work
- **SPA-only routes**: Only `/` is SSR'd. `/cn/article/{aid}` returns 404 with empty state. Content is loaded client-side after auth
- **Proxy-induced timeouts**: In environments behind a local proxy (e.g. mihomo on `127.0.0.1:7897`), TLS handshake through the proxy can take 15–30 seconds. Use `--connect-timeout 15 --max-time 45` and pass the proxy explicitly with `-x http://127.0.0.1:7897`. Direct connection (`--noproxy '*'`) will reach Cloudflare but receive a 301 redirect to `lightnovel.fun` which may then fail behind the same proxy
- **Author bracket display**: After extracting author from `[brackets]` in the title, always strip the bracket from the display title with `re.sub(r'\[.*?\]\s*', '', title)`. Otherwise reports show duplication like `[七星蛍] [七星蛍]班上最優秀的她...`.

## Reference files

- `references/api-and-architecture.md` — Full API endpoint catalog, NUXT parameter mapping, webpack chunk analysis, and data structure documentation
- `references/cdn-timestamps-and-dating.md` — CDN timestamp extraction technique, aid-to-date linear correlation data from observed sessions, items-vs-ranks comparison with field-by-field breakdown. Includes cross-session items persistence analysis and migration tracking
- `references/title-parsing.md` — Regex patterns for extracting author (from `[作者]` brackets) and volume/chapter info from title strings. Includes JP/KR/CN disambiguation heuristics, items-array fallback notes, and `clean_title()` for display.
- `references/known-series-authors.md` — Hardcoded lookup table mapping distinctive title substrings to confirmed authors. Use when items-array entries lack `[author]` brackets — enriches reports with known author names for recurring series.
- `scripts/parse_and_report.py` — Standalone CLI script: `python3 parse_and_report.py /tmp/ln_home.html --days 3`. Does the full fetch→parse→categorize→report pipeline and prints formatted output. Use as a reference implementation or invoke directly in cron jobs.

## Output format

When reporting to the user, use Chinese. Choose format based on context:

**Cron job / one-shot delivery** (user can't ask follow-ups) — use the **list format** with bullets, which is more readable in messaging platforms than markdown tables:

```
## 📚 轻之国度 · 日轻/韩轻翻译区 更新报告

**抓取时间**：… | **数据源**：… | **窗口**：… | **目录**：[category/3/106](url)

### 🆕 最近N天（X本）

1. **书名**
   └ 作者：XXX | 卷数：第N卷 | 更新：MM-DD | [阅读](url)

2. **书名**
   └ 作者：XXX | 卷数：第N卷 | 更新：MM-DD | [阅读](url)

### ⚠️ N~M天前（Y本）

1. **书名** → 作者：XXX | 第N卷 | MM-DD | [aid=N](url)
```

Keep entries compact — one metadata line per entry. Truncate titles >55 chars.

**Interactive session** (user can ask follow-ups) — use the compact table format:

```
| # | 书名 | 作者 | 卷数 | 更新时间 | 链接 |
|---|------|------|------|----------|------|
| 1 | **书名** | 作者 | 第N卷 | MM-DD | [aid=N](url) |
```

**Sparse window format** (≤2 entries in window): Use the sectioned report with three tiers to give context even when the target window is thin. Include `### 🆕`, `### ⚠️` (near miss), and `### 📊` (week remainder) sections.

Key rules:
- Only include 日轻/韩轻 (Japanese/Korean LN), exclude 国产网文
- Author names in brackets `[作者]` are the original JP/KR author — strip brackets from display title
- Volume info when available ("第N卷", "（上/下）", "已完结", "至第N话", "完")
- Links use `https://www.lightnovel.cn/cn/article/{aid}` format
- If nothing found in the window, state clearly and show the closest recent entries
- When running as a cron job, always use the sectioned list format — the user cannot ask follow-ups, give them the full picture
- For volume/author parsing regex patterns, see `references/title-parsing.md`
